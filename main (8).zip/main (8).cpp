#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdexcept>
#include <memory>
#include <sstream>
#include <algorithm>
#include <cctype>

using namespace std;

class Product {
protected:
    string name;
    double price;

public:
    Product(const string& name, double price) : name(name), price(price) {}

    virtual void display() const = 0;
    virtual ~Product() {}

    string getName() const {
        return name;
    }

    double getPrice() const {
        return price;
    }

    virtual string getInfo() const = 0;
    virtual unique_ptr<Product> clone() const = 0;
};

class Electronics : public Product {
    int warranty;

public:
    Electronics(const string& name, double price, int warranty)
        : Product(name, price), warranty(warranty) {}

    void display() const override {
        cout << "Електроніка: " << name << " - $" << price << " - Гарантія: " << warranty << " місяців" << endl;
    }

    string getInfo() const override {
        stringstream ss;
        ss << "Electronics," << name << "," << price << "," << warranty;
        return ss.str();
    }

    unique_ptr<Product> clone() const override {
        return make_unique<Electronics>(*this);
    }
};

class Book : public Product {
    string author;

public:
    Book(const string& name, double price, const string& author)
        : Product(name, price), author(author) {}

    void display() const override {
        cout << "Книга: " << name << " by " << author << " - $" << price << endl;
    }

    string getInfo() const override {
        stringstream ss;
        ss << "Book," << name << "," << price << "," << author;
        return ss.str();
    }

    unique_ptr<Product> clone() const override {
        return make_unique<Book>(*this);
    }
};

class Garden : public Product {
    string type;

public:
    Garden(const string& name, double price, const string& type)
        : Product(name, price), type(type) {}

    void display() const override {
        cout << "Садові товари: " << name << " - $" << price << " - Тип: " << type << endl;
    }

    string getInfo() const override {
        stringstream ss;
        ss << "Garden," << name << "," << price << "," << type;
        return ss.str();
    }

    unique_ptr<Product> clone() const override {
        return make_unique<Garden>(*this);
    }
};

class Food : public Product {
    int calories;

public:
    Food(const string& name, double price, int calories)
        : Product(name, price), calories(calories) {}

    void display() const override {
        cout << "Їжа: " << name << " - $" << price << " - Калорії: " << calories << " ккал" << endl;
    }

    string getInfo() const override {
        stringstream ss;
        ss << "Food," << name << "," << price << "," << calories;
        return ss.str();
    }

    unique_ptr<Product> clone() const override {
        return make_unique<Food>(*this);
    }
};

class Entertainment : public Product {
    string category;

public:
    Entertainment(const string& name, double price, const string& category)
        : Product(name, price), category(category) {}

    void display() const override {
        cout << "Розваги: " << name << " - $" << price << " - Категорія: " << category << endl;
    }

    string getInfo() const override {
        stringstream ss;
        ss << "Entertainment," << name << "," << price << "," << category;
        return ss.str();
    }

    unique_ptr<Product> clone() const override {
        return make_unique<Entertainment>(*this);
    }
};

class Health : public Product {
    string benefits;

public:
    Health(const string& name, double price, const string& benefits)
        : Product(name, price), benefits(benefits) {}

    void display() const override {
        cout << "Здоров'я: " << name << " - $" << price << " - Переваги: " << benefits << endl;
    }

    string getInfo() const override {
        stringstream ss;
        ss << "Health," << name << "," << price << "," << benefits;
        return ss.str();
    }

    unique_ptr<Product> clone() const override {
        return make_unique<Health>(*this);
    }
};

class Leisure : public Product {
    string activity;

public:
    Leisure(const string& name, double price, const string& activity)
        : Product(name, price), activity(activity) {}

    void display() const override {
        cout << "Дозвілля: " << name << " - $" << price << " - Діяльність: " << activity << endl;
    }

    string getInfo() const override {
        stringstream ss;
        ss << "Leisure," << name << "," << price << "," << activity;
        return ss.str();
    }

    unique_ptr<Product> clone() const override {
        return make_unique<Leisure>(*this);
    }
};

template <typename T>
class ProductList {
public:
    vector<unique_ptr<T>> products;

    void addProduct(unique_ptr<T> product) {
        products.push_back(move(product));
    }

    void removeProduct(const string& name) {
        products.erase(remove_if(products.begin(), products.end(),
            [&name](const unique_ptr<T>& product) {
                return product->getName() == name;
            }), products.end());
    }

    void displayAll() const {
        for (const auto& product : products) {
            product->display();
        }
    }

    vector<unique_ptr<T>> searchProduct(const string& keyword) const {
        vector<unique_ptr<T>> results;
        for (const auto& product : products) {
            stringstream ss;
            ss << product->getInfo();
            string info = ss.str();
            string lowerInfo = info;
            transform(lowerInfo.begin(), lowerInfo.end(), lowerInfo.begin(), ::tolower);
            string lowerKeyword = keyword;
            transform(lowerKeyword.begin(), lowerKeyword.end(), lowerKeyword.begin(), ::tolower);
            if (lowerInfo.find(lowerKeyword) != string::npos) {
                results.push_back(product->clone());
            }
        }
        return results;
    }

    void saveToFile(const string& filename) const {
        ofstream file(filename);
        if (!file) {
            throw runtime_error("Cannot open file");
        }
        for (const auto& product : products) {
            file << product->getInfo() << endl;
        }
    }

    void loadFromFile(const string& filename) {
        ifstream file(filename);
        if (!file) {
            throw runtime_error("Cannot open file");
        }
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string type, name;
            double price;
            getline(ss, type, ',');
            getline(ss, name, ',');
            ss >> price;

            if (type == "Electronics") {
                int warranty;
                ss >> warranty;
                addProduct(make_unique<Electronics>(name, price, warranty));
            } else if (type == "Book") {
                string author;
                getline(ss, author, ',');
                addProduct(make_unique<Book>(name, price, author));
            } else if (type == "Garden") {
                string gardenType;
                getline(ss, gardenType, ',');
                addProduct(make_unique<Garden>(name, price, gardenType));
            } else if (type == "Food") {
                int calories;
                ss >> calories;
                addProduct(make_unique<Food>(name, price, calories));
            } else if (type == "Entertainment") {
                string category;
                getline(ss, category, ',');
                addProduct(make_unique<Entertainment>(name, price, category));
            } else if (type == "Health") {
                string benefits;
                getline(ss, benefits, ',');
                addProduct(make_unique<Health>(name, price, benefits));
            } else if (type == "Leisure") {
                string activity;
                getline(ss, activity, ',');
                addProduct(make_unique<Leisure>(name, price, activity));
            }
        }
    }
};

class Customer {
    string name;
    vector<unique_ptr<Product>> cart;

public:
    Customer(const string& name) : name(name) {}

    void addToCart(unique_ptr<Product> product) {
        cart.push_back(move(product));
    }

    void removeFromCart(const string& name) {
        cart.erase(remove_if(cart.begin(), cart.end(),
            [&name](const unique_ptr<Product>& product) {
                return product->getName() == name;
            }), cart.end());
    }

    void showCart() const {
        cout << "Кошик " << name << ":" << endl;
        for (const auto& product : cart) {
            product->display();
        }
    }

    void clearCart() {
        cart.clear();
    }
};

int main() {
    try {
        ProductList<Product> store;
        store.addProduct(make_unique<Electronics>("Ноутбук", 999.99, 24));
        store.addProduct(make_unique<Book>("Програмування на C++", 39.99, "Б'ярне Страуструп"));
        store.addProduct(make_unique<Garden>("Газонокосарка", 299.99, "Електрична"));
        store.addProduct(make_unique<Food>("Яблуко", 0.99, 52));
        store.addProduct(make_unique<Entertainment>("Квиток в кіно", 12.99, "Кінотеатр"));
        store.addProduct(make_unique<Health>("Вітамін C", 19.99, "Підвищує імунітет"));
        store.addProduct(make_unique<Leisure>("Килимок для йоги", 24.99, "Йога"));

        Customer customer("Іван Шевченко");

        int choice;
        int userType;

        cout << "Виберіть тип користувача:\n";
        cout << "1. Продавець\n";
        cout << "2. Покупець\n";
        cin >> userType;

          if (userType == 1) {
              do {
                  cout << "\nМеню Продавця:\n";
                  cout << "1. Додати товар\n";
                  cout << "2. Видалити товар\n";
                  cout << "3. Показати всі товари\n";
                  cout << "4. Зберегти товари у файл\n";
                  cout << "5. Завантажити товари з файлу\n";
                  cout << "6. Вихід\n";
                  cout << "Виберіть опцію: ";
                  cin >> choice;

                  switch (choice) {
                      case 1: {
                          int productType;
                          string name, author, category, type, benefits, activity;
                          double price;
                          int warranty, calories;
                          cout << "Виберіть тип товару:\n";
                          cout << "1. Electronics\n";
                          cout << "2. Book\n";
                          cout << "3. Garden\n";
                          cout << "4. Food\n";
                          cout << "5. Entertainment\n";
                          cout << "6. Health\n";
                          cout << "7. Leisure\n";
                          cin >> productType;
                          cin.ignore();

                          cout << "Введіть назву товару: ";
                          getline(cin, name);
                          cout << "Введіть ціну: ";
                          cin >> price;

                          switch (productType) {
                              case 1:
                                  cout << "Введіть гарантію (у місяцях): ";
                                  cin >> warranty;
                                  store.addProduct(make_unique<Electronics>(name, price, warranty));
                                  break;
                              case 2:
                                  cin.ignore();
                                  cout << "Введіть автора: ";
                                  getline(cin, author);
                                  store.addProduct(make_unique<Book>(name, price, author));
                                  break;
                              case 3:
                                  cin.ignore();
                                  cout << "Введіть тип: ";
                                  getline(cin, type);
                                  store.addProduct(make_unique<Garden>(name, price, type));
                                  break;
                              case 4:
                                  cout << "Введіть калорії: ";
                                  cin >> calories;
                                  store.addProduct(make_unique<Food>(name, price, calories));
                                  break;
                              case 5:
                                  cin.ignore();
                                  cout << "Введіть категорію: ";
                                  getline(cin, category);
                                  store.addProduct(make_unique<Entertainment>(name, price, category));
                                  break;
                              case 6:
                                  cin.ignore();
                                  cout << "Введіть переваги: ";
                                  getline(cin, benefits);
                                  store.addProduct(make_unique<Health>(name, price, benefits));
                                  break;
                              case 7:
                                  cin.ignore();
                                  cout << "Введіть діяльність: ";
                                  getline(cin, activity);
                                  store.addProduct(make_unique<Leisure>(name, price, activity));
                                  break;
                              default:
                                  cout << "Неправильний вибір.\n";
                          }
                          break;
                      }
                      case 2: {
                          string name;
                          cin.ignore();
                          cout << "Введіть назву товару для видалення: ";
                          getline(cin, name);
                          store.removeProduct(name);
                          break;
                      }
                      case 3:
                          store.displayAll();
                          break;
                      case 4: {
                          string filename;
                          cin.ignore();
                          cout << "Введіть назву файлу: ";
                          getline(cin, filename);
                          store.saveToFile(filename);
                          break;
                      }
                      case 5: {
                          string filename;
                          cin.ignore();
                          cout << "Введіть назву файлу: ";
                          getline(cin, filename);
                          store.loadFromFile(filename);
                          break;
                      }
                      case 6:
                          cout << "Вихід з меню продавця.\n";
                          break;
                      default:
                          cout << "Неправильний вибір. Спробуйте ще раз.\n";
                  }
              } while (choice != 6);
          } else if (userType == 2) {
              do {
                  cout << "\nМеню Покупця:\n";
                  cout << "1. Показати всі товари\n";
                  cout << "2. Додати товар до кошика\n";
                  cout << "3. Видалити товар з кошика\n";
                  cout << "4. Показати кошик\n";
                  cout << "5. Вихід\n";
                  cout << "Виберіть опцію: ";
                  cin >> choice;

                  switch (choice) {
                      case 1:
                          store.displayAll();
                          break;
                      case 2: {
                          string name;
                          cin.ignore();
                          cout << "Введіть назву товару для додавання до кошика: ";
                          getline(cin, name);

                          auto it = find_if(store.products.begin(), store.products.end(),
                              [&name](const unique_ptr<Product>& product) {
                                  return product->getName() == name;
                              });

                          if (it != store.products.end()) {
                              customer.addToCart(unique_ptr<Product>((*it)->clone()));
                              cout << "Товар додано до кошика.\n";
                          } else {
                              cout << "Товар не знайдено.\n";
                          }

                          break;
                      }
                      case 3: {
                          string name;
                          cin.ignore();
                          cout << "Введіть назву товару для видалення з кошика: ";
                          getline(cin, name);
                          customer.removeFromCart(name);
                          break;
                      }
                      case 4:
                          customer.showCart();
                          break;
                      case 5:
                          cout << "Вихід з меню покупця.\n";
                          break;
                      default:
                          cout << "Неправильний вибір. Спробуйте ще раз.\n";
                  }
              } while (choice != 5);
          } else {
              cout << "Неправильний вибір типу користувача.\n";
          }
          } catch (const exception& e) {
          cout << "Помилка: " << e.what() << endl;
          }

          return 0;
          }
